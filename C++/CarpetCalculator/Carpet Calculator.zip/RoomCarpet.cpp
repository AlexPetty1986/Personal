#include "RoomCarpet.h"

//Constructor
RoomCarpet::RoomCarpet()
{

}

//Initializes the room dimensions and the price
RoomCarpet::RoomCarpet(RoomDimension r, double p)
{
    room = r;
    price = p;
}

//Sets the dimensions of the room
void RoomCarpet::setRoom(RoomDimension r)
{
    room = r;
}

//Sets the price of the carpet per square foot
void RoomCarpet::setCost(double p)
{
    price = p;
}

//calculates the total cost of the carpet
double RoomCarpet::totalCost()
{
    double totalPrice, roomArea;
    RoomDimension measure;
    measure = room;
    roomArea = measure.getArea();
    totalPrice = roomArea * price;
    return totalPrice;
}
