#ifndef ROOMCARPET_H_INCLUDED
#define ROOMCARPET_H_INCLUDED
#include <iomanip>

#include "RoomDimension.h"

class RoomCarpet
{
private:
    RoomDimension room; //The room that the user wants a carpet in
    double price;       //Price of the carpet per square foot
public:
    //Constructors
    RoomCarpet();
    RoomCarpet(RoomDimension, double);

    //Mutator Functions
    void setRoom(RoomDimension);
    void setCost(double);

    //Accessor Functions
    double totalCost();
};

#endif // ROOMCARPET_H_INCLUDED
