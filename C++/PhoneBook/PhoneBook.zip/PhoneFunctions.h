#ifndef PHONEFUNCTIONS_H_INCLUDED
#define PHONEFUNCTIONS_H_INCLUDED
#include <iostream>
#include <string>
#include <iomanip>

using namespace std;

const int SIZE = 10; //Total size of the array

void LocateContacts(const string data[], int size);

#endif // PHONEFUNCTIONS_H_INCLUDED
