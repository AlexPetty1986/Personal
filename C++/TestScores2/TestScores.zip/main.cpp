#include <iostream>
#include "TestScores.cpp"

using namespace std;

//The main function of the program
int main()
{
    //Holds the values of the grades
    //Two of them show that the exception classes work
    //While one of them shows that getAverage actually gets the average
    double testGrades1[] = {67, 105, 87, 50, 12};
    double testGrades2[] = {79, 66, 43, 50, 99};
    double testGrades3[] = {81, 100, 63, 55, -9};

    //First set of grades
    //This set has a score higher than 100 to show that TooLargeScore works
    TestScores<double> grades1(testGrades1);

    //Tries to display the average of the grades
    try
    {
        cout << setprecision(2) << fixed << showpoint;
        cout << "Grade Average: " << grades1.getAverage() << endl;
    }

    //Catches if the score is greater than 100
    catch(TooLargeScore problem)
    {
        cout << problem.getMessage() << problem.getScore() << endl;
    }

    //Catches if a score is less than 0
    catch(NegativeScore problem)
    {
        cout << problem.getMessage() << problem.getScore() << endl;
    }

    //Second set of grades
    //This set has no score higher than 100 r greater than 0
    //Shows that GetAverage actually works
    TestScores<double> grades2(testGrades2);

    //Tries to display the average of the grades
    try
    {
        cout << setprecision(2) << fixed << showpoint;
        cout << "Grade Average: " << grades2.getAverage() << endl;
    }

    //Catches if the score is greater than 100
    catch(TooLargeScore problem)
    {
        cout << problem.getMessage() << problem.getScore() << endl;
    }

    //Catches if a score is less than 0
    catch(NegativeScore problem)
    {
        cout << problem.getMessage() << problem.getScore() << endl;
    }

    //Third set of grades
    //This set has a negative number to show that NegativeScore works
    TestScores<double> grades3(testGrades3);

    //Tries to display the average of the grades
    try
    {
        cout << setprecision(2) << fixed << showpoint;
        cout << "Grade Average: " << grades3.getAverage() << endl;
    }

    //Catches if the score is greater than 100
    catch(TooLargeScore problem)
    {
        cout << problem.getMessage() << problem.getScore() << endl;
    }

    //Catches if a score is less than 0
    catch(NegativeScore problem)
    {
        cout << problem.getMessage() << problem.getScore() << endl;
    }

    return 0;
}
